export class User {
  jti!: String;
  name!: String;
  emailaddress!: String;
  Roles!: string
}
