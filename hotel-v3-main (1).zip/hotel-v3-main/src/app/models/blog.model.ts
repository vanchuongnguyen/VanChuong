export class Blog {
  id!: number ;
  shortTitle!: string ;
  longTitle!: string ;
  createdAt!: Date ;
  image!: string ;
  longContent!: string ;
  shortContent!: string ;
  posterEmail!: string ;
  posterRoles!: string ;
}
