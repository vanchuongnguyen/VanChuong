import { TokenModel } from "../_service/token.model";

export class StatusToken {
  status!: boolean;
  token!: TokenModel;

}
