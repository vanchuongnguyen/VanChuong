export interface Payment {
  priceTotal: number ;
  orderInfo: string ;
  orderType: string ;
  payType: string ;
  status: number ;
  message: string ;
  reservationId: string;

}

