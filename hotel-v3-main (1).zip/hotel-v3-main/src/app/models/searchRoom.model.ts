export class SearchRoom {
  checkIn! : Date;
  checkOut! : Date;
  peopleNumber! : number;
  price! : number;
  star! : number;
  typeRoomId! : number;
}
