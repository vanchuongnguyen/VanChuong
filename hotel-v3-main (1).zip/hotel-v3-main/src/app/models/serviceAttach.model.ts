export class ServiceAttach {
  id!: string
  name!: string
  icon!: string
  description!: string
}
