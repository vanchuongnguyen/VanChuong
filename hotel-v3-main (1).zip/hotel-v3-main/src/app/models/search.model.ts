export class Search {
  id!: number;
  typeName!: string;
  maxPerson!: number;
}
