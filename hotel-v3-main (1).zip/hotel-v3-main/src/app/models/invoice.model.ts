export class Invoice {
  priceTotal!: number ;
  orderInfo!: string ;
  orderType!: string ;
  payType!: string ;
  status!: 0 ;
  message!: string ;
  reservationId!: string;
}
