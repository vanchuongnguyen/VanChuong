export const environment = {
  BASE_URL_API : "https://webhotel.click",
  // BASE_URL_API : "https://localhost:7103",
  BASE_URL_WEB : "http://localhost:4200",
  QR_MOMO:`https://webhotel.click/user/payment/momoQR`,

  spaceId: 'e76861lm8t6b',
  accessToken: 'pJnp8KyAqAWRsXB0-m0p0ULvJnQRYHxB-QIRkK1AUPw',
  createContent: 'https://app.contentful.com/spaces/e76861lm8t6b/home'
};

