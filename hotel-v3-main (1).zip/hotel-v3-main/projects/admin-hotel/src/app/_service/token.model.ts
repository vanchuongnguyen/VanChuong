export interface TokenModel {
  accessToken: any;
  refreshToken: any;
}
