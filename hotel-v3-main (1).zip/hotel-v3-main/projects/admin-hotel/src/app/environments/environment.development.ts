export const environment = {
  BASE_URL_API : "https://webhotel.click",
//   BASE_URL_API : "https://localhost:7103",
  BASE_URL_WEB : "http://localhost:8000",
};
