export class Salary {
   id!: string
   basicSalary!: number
   numberOfDays!: number
   allowance!: number
   workTime!: Date
   employeeId!: string


}
