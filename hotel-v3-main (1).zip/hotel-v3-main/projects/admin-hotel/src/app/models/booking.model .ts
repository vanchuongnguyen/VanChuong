export class Booking {
  roomId!: number
  name!: string
  startDate!: Date
  endDate!: Date
  imgTitle!: string
  address!: string
  numberOfDay!: number
  phoneNumber!: string
}
