import { Binary } from "@angular/compiler"

export class userProfile {
  userName!: string
  phoneNumber!: string
  email!: string
  image!: any
  address!: string
  cmnd!: string
  createdAt!: Date
  name!: string
}
