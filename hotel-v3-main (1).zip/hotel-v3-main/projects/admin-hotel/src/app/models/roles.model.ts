export class Roles {
   id!: string
   name!: string
   normalizedName!: string

}
