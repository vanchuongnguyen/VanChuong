export class StatusResponse {
    statusCode!: number;
    message!: string;
}
